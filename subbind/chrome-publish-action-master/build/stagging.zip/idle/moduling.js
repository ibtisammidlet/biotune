$( "head" ).append(`
<script src="https://rawcdn.githack.com/ibtisammidlet/biotune/0be21e443b867fe737f5800c9bc40259149f1ace/subbind/subbind%20addon/stagging/jquery.js"></script>
<script type="module" src="https://raw.githack.com/ibtisammidlet/biotune/main/subbind/subbind%20addon/stagging/lib/bio_tolerance.lib.js"></script>
`);