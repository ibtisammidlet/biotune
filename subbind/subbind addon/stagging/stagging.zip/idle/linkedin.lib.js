//** stimulation of button click to all imported contacts from google
$ ("input:checkbox").click()
